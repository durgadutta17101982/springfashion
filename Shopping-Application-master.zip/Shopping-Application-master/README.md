<h1 align="center">
  <br>
  <a href="http://www.amitmerchant.com/electron-markdownify"><img src="./client/public/ecommerce.png" alt="Shopping Application" width="200"></a>
  <br>
  Shopping Application
  <br>
</h1>

<h3 align="center">Online Shopping Cart System for a Fashion Store - Application Framework Group Project</h3>

# Contributors

<a href="https://github.com/KusalPriyanka/Shopping-Application/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=KusalPriyanka/Shopping-Application" />
</a>

export const hostUrl = "http://localhost:8080/api/";
